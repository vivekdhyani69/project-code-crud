<?php
include("config.php");
if(isset($_GET['id'])){
    $id=$_GET['id'];//iske ander delete vali id pass krdi main vali and stored in id
$q="DELETE FROM categories WHERE id='$id'";//delete vali id me store kradi table me delete ki id
if(mysqli_query($conn,$q))
{
    header("loaction:categories.php");
}
}


?>