function validateform() {

    var name = document.getElementById("firstName").value;
    var lname = document.getElementById("lastname").value;
    var contact = document.getElementById("contact").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmpassword = document.getElementById("cpassword").value;

    if (name == "") {
        document.getElementById("firstName").style.border = "2px solid red";
        document.getElementById('error').innerHTML = "*Please enter a username*";

    }
    if (lname == "") {
        document.getElementById("lastname").style.border = "2px solid red";
        document.getElementById('error1').innerHTML = "*Please enter a Lastname*";

    }

     if (contact == "") {
        document.getElementById("contact").style.border = "2px solid red";
        document.getElementById('error2').innerHTML = "*Please enter Your Contact No.*";

    }

    if (email == "") {
        document.getElementById("email").style.border = "2px solid red";
        document.getElementById('error3').innerHTML = "*Please enter your email*";

    }

    if (password.length < 6) {
        document.getElementById("password").style.border = "2px solid red";
        document.getElementById('error4').innerHTML = "*Please enter your password*";

    }
    if (confirmpassword.length < 6) {
        document.getElementById("cpassword").style.border = "2px solid red";
        document.getElementById('error5').innerHTML = "*Please enter your confirm password*";

    }

    // <td><?php echo "<a class='btn btn-sm btn-primary' href='update.php?id=" . $res['id'] . "&ti=" . $res['Title'] . " &con=" . $res['Content'] . "'>Update</a>; ?></td>
}  