<?php

include("config.php");

$id=$_GET['id'];
$title=$_GET['title'];
$cont=$_GET['content'];

if (isset($_POST['submit'])) {
    $id = $_GET['id']; //fetch id
    $title = $_POST['title'];
    $content = $_POST['content'];

    $sql = "update post SET id=$id, Title='$title',Content='$content' where id=$id ";

    $result = mysqli_query($conn, $sql);
    header('location:display.php?update=true');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add-post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row py-5">

            <div class="col-12 col-md-12 col-lg-5 mx-auto text-center border border-dark border-black">
                <?php
                if (isset($result)) {
                    if ($result) {
                ?>
                        <div class="alert alert-success">
                            <strong>Success!</strong>Data Successfully Added in Table</a>.
                        </div>
                    <?php } else { ?>
                        <div class="alert alert-danger">
                            <strong>Failed!</strong> Some error occured</a>.
                        </div>
                <?php
                    }
                }
                ?>

                <h1 class='text-center text-success'>Update Operation</h1>
                <hr>
                <form action='' method="POST">
                    <input type="text text-white" name="title" value=<?php echo $title?> placeholder="TITLE">
                    <br>
                    <div class="py-3">
                        <input type="text text-white" name="content"  value=<?php echo $cont?> placeholder="CONTENT">
                    </div>
                    <input type="submit" name="submit" value="Update">
                </form>

            </div>
        </div>

    </div>
</body>

</html>