  <?php
  include 'config.php';

  ?>

  <header>
    <div class="bg-dark container-fluid  py-4">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand text-white" href="#">All-Logos</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
          <ul class="navbar-nav ml-auto ">
            <li class="nav-item active  ">
              <a class="nav-link text-white" href="welcome.php">Home </span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link text-white" href="display.php">Display</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link text-white" href="categories.php">Categories</a>
            </li>

            <li class="nav-item active">
              <a class="nav-link text-white" href="#">Services</a>
            </li>

            <li class="nav-item active">

              <a class="nav-link text-white" href="logout.php" name="logout">Log-Out</a>

            </li>
          </ul>
        </div>
      </nav>

    </div>

  </header>
  <strong>
    <?php

    echo " Welcome!
  " . $_SESSION["email"];
    ?>

    <?php
    // echo "
    //   " . $_SESSION["userid"];
    ?>


  </strong>