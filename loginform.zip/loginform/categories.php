<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Categories.php</title>
</head>
<?php include 'header.php'; ?>

<body>
    <div class="py-1">
        <div class="container">

            <div class="row">
                <div class="col-md-12  text-right" style="margin: 15px;">


                    <a class="btn btn-primary text-white" href="addcategories.php">Add Categories</a>
                </div>

            </div>
            <?php
            if (isset($_GET['success'])) { ?>
                <div class="alert alert-success"><strong>Successfully!</strong> Stored </a>
                </div>

            <?php }
            ?>

            <?php
            if (isset($_GET['sar'])) { ?>
                <div class="alert alert-success">
                    <strong>Successfully!</strong> Edit</a>
                </div>

            <?php    }
            ?>

            <h1 class="text-warning text-center">Display Table Data</h1>

            <table class="table table-sm my-4 table-hover border border-dark" method="post">
                <thead class="bg-dark text-white">
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">Content</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>


                <?php


                $userid = $_SESSION["userid"];

                $result = "select * from categories where userid='$userid'";

                if (isset($_GET['page']) && $_GET['page'] != 1) {
                    $page = $_GET['page'];
                    $page = $page - 1;
                    $offset = 10 * $page;
                } else {
                    $page = 0;
                    $offset = 0;
                }
                $prepage = 10; //start from

                $cquery = "select count(*) as total from categories where userid=$userid";
                $cdata = mysqli_query($conn, $cquery);
                $ctotal = mysqli_fetch_assoc($cdata);
                $result = "select * from categories where userid=$userid ORDER BY id DESC  LIMIT $offset, $prepage";
                //Yha se post table k ander ka sara data mil fetch ho jayega
                //Yha se post table k ander ka sara data mil fetch ho jayega
                $query = mysqli_query($conn, $result); //ye data array ki form me store ho gya hai
                $total = mysqli_num_rows($query);
                while ($res = mysqli_fetch_array($query)) {
                ?>

                    <tbody>
                        <tr>
                            <td><?php echo $res['id']; ?></td>

                            <td><?php echo $res['Content']; ?></td>

                            <td><button class="btn btn-success"> <a href="categoriesupdate.php?id=<?php echo $res['id'];?>&content=<?php echo $res['Content'];?>" class="text-white">Edit</a></button></td>

                            <td><button class="btn btn-danger"> <a href="categoriesdelete.php?id=<?php echo $res['id'];?>" onclick='return checkdelete()' class="text-white">Delete</a></button></td>

                        </tr>
                    </tbody>

                    
                <?php
                }
                ?>
            </table>
            <script>
                function checkdelete() {
                    return confirm('Are you sure you went to delete');
                }
            </script>
        </div>
    </div>
    <nav aria-label="Page navigation example">
        <ul class="pagination pagination-lg justify-content-center">
            <li class="page-item <?php if ($page == 0) echo 'disabled'; ?>">
                <a class="page-link" href="categories.php?page=<?php echo $page; ?>">Previous</a>
            </li>

            <li class="page-item  <?php if ($ctotal['total'] < ($page + 1) * 10) echo 'disabled'; ?>">
                <a class="page-link" href="categories.php?page=<?php echo $page + 2; ?>">Next</a>
            </li>
        </ul>
    </nav>
</body>

</html>