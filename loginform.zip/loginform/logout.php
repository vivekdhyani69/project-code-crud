<?php
include "config.php";
    session_start();
   unset( $_SESSION['email'] );//this will unset the session and makes sessions variable empty
    session_destroy();
    header("location: Login.php");
?>