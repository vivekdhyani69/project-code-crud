<?php

include 'header.php';
$cquery = "select id,Content from categories ORDER BY 'id' DESC";

$cdata = mysqli_query($conn, $cquery);

?>
<?php
if (isset($_POST['submit'])) {

    $title = $_POST['title'];
    $content = $_POST['content'];
    $userid = $_SESSION["userid"];
    $categories = $_POST['categories']; ///database
    if (
        $title != "" ||
        $content != ""
    ) {

        $sql = "INSERT INTO post(Title,Content,userid)
    VALUES ('$title','$content','$userid' )";
        if (mysqli_query($conn, $sql)) {
            $post_id = $conn->insert_id;
            for ($i = 0; $i < count($categories); ++$i) {
                $pcat = "INSERT INTO post_cat_link (post_id,cate_id) VALUES('$post_id','$categories[$i]')";

                if (mysqli_query($conn, $pcat)) {
                } else {

                    echo $_POST[$conn->error];
                }
            }
        }

        header("Location:display.php?success=true");
    } else {
        header("Location:addpost.php?display=true");
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add-post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row py-5">

            <div class="col-12 col-md-12 col-lg-5 mx-auto  border border-dark border-black">
                <?php
                if (isset($_GET['display'])) { ?>
                    <div class="alert alert-danger">
                        <strong>Failed!</strong> Please Fill Empty Field</a>.
                    </div>
                <?php }  ?>



                <h1 class=text-center>Post Upload</h1>
                <hr>
                <form action='' method="POST">
                    <div>
                        <label for="title">Title</label>
                        <input type="text text-white" class="form-control" name="title" id="title" placeholder="TITLE">
                        <br>
                        <span id="error"></span>
                    </div>
                    <div class="py-3">
                        <label for="content">Content</label>
                        <input type="text text-white" class="form-control" name="content" id="content" placeholder="CONTENT">
                        <br>
                        <span id="error1"></span>
                    </div>

                    <label for="categories">Select Categories</label>
                    <select name="categories[]" multiple class="form-control" id="categories">
                        <option selected>Select Categories</option>
                        <?php while ($result = mysqli_fetch_array($cdata)) { ?>

                            <option value="<?php echo $result['id']; ?>"><?php echo $result['Content']; ?>
                            </option>

                        <?php }
                        ?>


                    </select>
                    <br>
                    <div class="text-center">
                        <input type="submit" name="submit" class="bg-primary text-white" value="AddPost">
                    </div>
                </form>

            </div>
        </div>

    </div>
    <style>
        select {
            color: #606060 !important;
        }

        select option {
            color: black;
        }

        select option:first-child {
            color: #606060 !important;
        }
    </style>

</body>

</html>