<?php
include'config.php';

if (isset($_POST['submit'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    $emailquery = "select email from register where email = '{$email}'";///query table me email hai then
    $query = mysqli_query($conn, $emailquery)or die("Query-failed");//makes connection
  
     $emailcount = mysqli_num_rows($query);
    if ($emailcount > 0) {//same email to nhi dal rahe

        echo "email already exist";
    } else {

        if (($password == $confirm_password)) {
         $hash=password_hash($password,PASSWORD_DEFAULT);

            $sql = "INSERT INTO register(firstname,lastname,email,Contact,Password)
            VALUES ('$first_name','$last_name','$email','$contact','$hash')";
echo "$sql";

            if (mysqli_query($conn, $sql)) {

              header('location: login.php?var=true');

            } 
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration-Form</title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="container">
        <div class="span12" style="padding-left: 100px;">
            <div class="row my-4 mx-5 w-75 ">
                <div class="col-12 col-md-12  border border-dark py-2 ">

                    <h1 class="text-center">Register</h1>
                    <p class="text-center">Please fill in this form to create an account </p>
                    <hr>

                    <?php
                    if (isset($query)) {
                        if ($query) {
                    ?>
                            <div class="alert alert-danger">
                                <strong>Failed!</strong> Some error occur</a>.
                            </div>
                        <?php } else { ?>
                            <div class="alert alert-danger">
                                <strong>Failed!</strong> Some error occured</a>.
                            </div>
                    <?php
                        }
                    }
                    ?>

<!-- /////////////////////////////////////Form Validation////////////////////////// -->

                    <form name="myForm" action="Registration.php" method="post">


                        <div class="form-group input-control">
                            <label class="py-2"><strong>Name</strong></label>
                            <br>
                            <input type="text" name="first_name" id="firstName" placeholder="Enter your Name" required class="py-2">
                            <br>
                            <span id="error"></span>

                        </div>


                        <div>
                            <label class="py-2"><strong>Last Name</strong></label>
                            <br>
                            <input type="text" name="last_name" id="lastname" placeholder="Enter last_name" required class="py-2">

                            <br>
                            <span id="error1"></span>
                        </div>

                        <div>
                            <label class="py-2"><strong>Contact No.</strong></label>
                            <br>
                            <input type="text" name="contact" id="contact" placeholder="Enter your Contact No." required class="py-2">
                            <br>
                            <span id="error2"></span>
                        </div>

                        <div>
                            <label class="py-2"><strong>Email</strong></label>
                            <br>
                            <input type="text" name="email" id="email" placeholder="Enter your Email" required class="py-2">

                            <br>
                            <span id="error3"></span>
                        </div>

                        <div>
                            <label class="py-2"><strong>Password</strong></label>
                            <br>
                            <input type="password" name="password" id="password" placeholder="Enter your Password" required class="py-2">

                            <br>
                            <span id="error4"></span>
                        </div>

                        <div>
                            <label class="py-2"><strong> Confirm Password</strong></label>
                            <br>
                            <input type="password" name="confirm_password" id="cpassword" placeholder="Enter your Confirm Password" required class="py-2">
                            <br>
                            <span id="error5"></span>

                        </div>

                        <p class="py-3">By creating an account you agree to our <a class="text-primary" href="#">Terms &
                                Privacy</a> </p>

                        <input style="width:100%; height: 50px; background-color:rgb(47, 202, 47);" onclick="validateform()" type="submit" name="submit" value="Register">

                        <p class="py-3">Already have an account ? <a class="text-primary"href="login.php">Sign-in</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js">
    </script>

</body>

</html>